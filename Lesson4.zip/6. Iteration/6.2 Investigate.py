print("Enter a number between 50 and 100")
num1 = int(input())

while num1 < 50 or num1 > 100:

  if num1 < 50:
    print("Invalid number, too small, try again.")
   
  num1 = int(input())


# Give the line number where the iteration starts.
  # Answer

# How many conditions are there in the code?  What are they?
  # Answer

# Give the line number where the nesting starts.
  # Answer

# Why are lines 6 and 9 indented?
  # Answer

# Why is line 7 indented twice?
  # Answer

# What would be the impact of swapping the 'or' on line 4 for an 'and'?
  # Answer