rockStars = ["John","Paul","George","Ringo","Freddie","Brian","John","Roger"]

print(rockStars[3:6])

print(rockStars[:5])

print(rockStars[4:])