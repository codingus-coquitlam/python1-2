rockStars = ["John","Paul","George","Ringo","Freddie","Brian","John","Roger"]

listLength = len(rockStars)

print(rockStars[3:listLength])

# What does the len() function do?

# If 'Axl' was appended to the list, what would be the effect on the listLength variable?

# What would be the effect on the output?