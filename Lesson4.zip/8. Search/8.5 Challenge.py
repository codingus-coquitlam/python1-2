import random

list_1 = []
counter = 0
while counter < 7:
    computersPick = random.randint(1,51)
    print(computersPick)
    list_1.append(computersPick)
        if computersPick in list_1:
            list_1.remove(computersPick)   
            counter -= 1
    counter += 1

     
print(list_1)







# Create a function that ouputs result like below lines

# >>> Today's lottery numbers are: 
# [7, 13, 16, 37, 46, 49, 50]
# >>> Your bonus number is 
# 19