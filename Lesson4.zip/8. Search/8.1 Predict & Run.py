######### Example 1 ######################

rockStars = ["John","Paul","George","Ringo","Freddie","Brian","John","Roger"]

counter = 0
found = False

while counter < len(rockStars):
  
  if rockStars[counter] == "George":
    found = True

  counter +=1

if found == True:
  print("George is in the list")
else:
  print("George is not in the list")

######## Example 2 #####################

if "George" in rockStars:
  print("George is in the list")
else:
  print("George is not in the list")

######## Example 3 ######################

counter = 0
found = False

while counter < len(rockStars) and found == False:
  
  if rockStars[counter] == "George":
    found = True

  counter +=1

if found == True:
  print("George is in the list")
else:
  print("George is not in the list")