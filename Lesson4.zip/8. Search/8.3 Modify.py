# Starter Code

rockStars = ["John","Paul","George","Ringo","Freddie","Brian","John","Roger"]

counter = 0
found = False

while counter < len(rockStars):
  
  if rockStars[counter] == "George":
    found = True

  counter +=1

if found == True:
  print("George is in the list")
else:
  print("George is not in the list")