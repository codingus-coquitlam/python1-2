
def sum_calc_using_for_loop(numberTuple):
    s = 0
    for n in numberTuple:
        s += n
    return s 

num1 = int(input("Enter number 1"))
num2 = int(input("Enter number 2"))

myTuple = (num1, num2)

sum = sum_calc_using_for_loop(myTuple)
print(sum)


# def sum_calc_using_while_loop(numberTuple):
#     s = 0
#     while :

#     return s 

# num1 = int(input("Enter number 1"))
# num2 = int(input("Enter number 2"))

# myTuple = (num1, num2)

# sum = sum_calc_using_while_loop(myTuple)
# print(sum)