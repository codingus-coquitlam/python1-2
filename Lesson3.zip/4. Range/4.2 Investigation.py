# Example Code

print("Enter the number of the month in which you were born.")
birthMonth = int(input())

if birthMonth >= 1 and birthMonth <=12:
  print("Thanks")
else:
  print("That's not a valid month!")

# What is the Boolean operator in the code?
  # Answer

# What does <= mean?
  # Answer

# What would the effect be of changing >= 1 to > 1 on line 7?
  # Answer