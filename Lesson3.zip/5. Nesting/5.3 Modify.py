name = input.lower("")

homeTown =

if name == "":



else: 



