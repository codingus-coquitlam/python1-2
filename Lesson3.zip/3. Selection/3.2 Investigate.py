name = "Dave"
homeTown = "Seattle"

if name == "Dave" and homeTown == "Seattle":
  print("Hi there Dave from Seattle!")
else:
  print("You're not Dave from Seattle!")

if name == "Dave" or homeTown == "Seattle":
  print("You're either called Dave or you're from Seattle!")
else:
  print("You're not Dave, and you aren't from Seattle!")

# How many selection statements are there in the code?
  # Answer

# What would the outputs be for Kurt From Seattle?
  # Answer

# What would the outputs be for Krist from Chicago?
  # Answer

# What would the effect be of changing the 'and' on line 8 to an 'or'?
  # Answer